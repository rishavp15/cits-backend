# Copyright 2025 PhonePe Private Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from unittest import TestCase

from phonepe.sdk.pg.env import Env
from phonepe.sdk.pg.payments.v2.custom_checkout_client import CustomCheckoutClient


class BaseCustomCheckoutClientForTest(TestCase):
    custom_checkout_client = None

    def setUp(self) -> None:
        BaseCustomCheckoutClientForTest.custom_checkout_client = CustomCheckoutClient.get_instance(
            client_id="client_id",
            client_version=1,
            client_secret="client_secret",
            env=Env.SANDBOX,
            should_publish_events=False)

    @staticmethod
    def set_client():
        if BaseCustomCheckoutClientForTest.custom_checkout_client is None:
            BaseCustomCheckoutClientForTest.custom_checkout_client = CustomCheckoutClient.get_instance(
                client_id="client_id",
                client_version=1,
                client_secret="client_secret",
                env=Env.SANDBOX,
                should_publish_events=False)

    def del_client(self):
        BaseCustomCheckoutClientForTest.custom_checkout_client.__del__()
